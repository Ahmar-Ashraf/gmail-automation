document.getElementById("automationForm").addEventListener("submit", function(event) {
    event.preventDefault();
    let numAccounts = document.getElementById("numAccounts").value;
    let statusMessage = document.getElementById("statusMessage");
    statusMessage.textContent = "Starting automation...";
    fetch("/create_accounts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ num_accounts: parseInt(numAccounts) })
    })
    .then(response => response.json())
    .then(data => {
        statusMessage.textContent = data.status === "success" ? "Automation started!" : "Error: " + data.message;
    })
    .catch(error => {
        statusMessage.textContent = "Request failed: " + error;
    });
});

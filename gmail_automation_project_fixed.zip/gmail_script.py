import time
import random
import os
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import undetected_chromedriver as uc
from faker import Faker
import logging

logging.basicConfig(level=logging.INFO)
fake = Faker()

def create_gmail_account():
    first_name = fake.first_name()
    last_name = fake.last_name()
    username = f"{first_name.lower()}{last_name.lower()}{random.randint(1000,9999)}"
    password = f"{fake.word()}_{random.randint(10000,99999)}"
    logging.info("Creating account: %s@gmail.com", username)
    try:
        options = webdriver.ChromeOptions()
        options.add_argument("--start-maximized")
        options.add_argument("--disable-blink-features=AutomationControlled")
        driver = uc.Chrome(options=options)
        wait = WebDriverWait(driver, 15)
        driver.get("https://accounts.google.com/signup")
        wait.until(EC.presence_of_element_located((By.ID, "firstName"))).send_keys(first_name)
        wait.until(EC.presence_of_element_located((By.ID, "lastName"))).send_keys(last_name)
        wait.until(EC.presence_of_element_located((By.ID, "username"))).send_keys(username)
        wait.until(EC.presence_of_element_located((By.NAME, "Passwd"))).send_keys(password)
        wait.until(EC.presence_of_element_located((By.NAME, "ConfirmPasswd"))).send_keys(password)
        wait.until(EC.element_to_be_clickable((By.ID, "accountDetailsNext"))).click()
        logging.info("Account created: %s@gmail.com", username)
    except Exception as e:
        logging.error("Error creating account: %s", e)
    finally:
        driver.quit()

if __name__ == '__main__':
    import sys
    num_accounts = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    for _ in range(num_accounts):
        create_gmail_account()
        time.sleep(random.randint(5, 10))

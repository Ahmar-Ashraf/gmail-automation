# Gmail Automation Project Enhanced

This is an enhanced, production-ready version of the Gmail Automation project.

## Project Structure
- `app.py` - Flask backend serving the web interface and triggering account creation.
- `gmail_script.py` - Script that automates Gmail account creation.
- `requirements.txt` - Python dependencies.
- `Dockerfile` and `docker-compose.yml` - For containerized deployment.
- `templates/` - Contains `index.html`.
- `static/` - Contains `style.css` and `script.js`.

## Setup Instructions
1. Build and run using Docker Compose:
   ```
   docker-compose up --build
   ```
2. Access the web interface at `http://localhost:5000`.

## Notes
- Ensure that you have the necessary dependencies and Chrome drivers.

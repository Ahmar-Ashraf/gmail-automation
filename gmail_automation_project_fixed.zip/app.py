from flask import Flask, request, jsonify, render_template
import subprocess
import threading
import logging

logging.basicConfig(level=logging.INFO)

app = Flask(__name__)

def run_gmail_script(num_accounts):
    try:
        subprocess.Popen(["python", "gmail_script.py", str(num_accounts)])
        logging.info("Automation started for %s accounts", num_accounts)
    except Exception as e:
        logging.error("Error starting automation: %s", e)

@app.route('/')
def index():
    return render_template('index.html')

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=10000)
